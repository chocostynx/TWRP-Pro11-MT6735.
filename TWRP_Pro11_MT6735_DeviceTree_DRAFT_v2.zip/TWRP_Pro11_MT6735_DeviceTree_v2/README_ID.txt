TWRP DEVICE-TREE PREPARATION DRAFT v2 — XSD Pro11 / MT6735

STATUS
- This is a source scaffold only. It is NOT a compiled or tested recovery image.
- Do NOT flash this ZIP or any image built from it without further validation.
- The user reports the tablet currently boots and Magisk 31.1 is stable. Preserve that working state.

VERIFIED FROM THE SUPPLIED boot.img AND recovery.img
- Both files are 16,777,216 bytes (16 MiB) Android boot images.
- Android boot image magic: ANDROID!
- Legacy header layout, page size 2048 bytes, dt_size 0.
- Kernel address: 0x40008000; ramdisk address: 0x44000000; tags address: 0x4e000000.
- Kernel payload size: 6,868,710 bytes.
- boot.img ramdisk size: 2,055,662 bytes.
- recovery.img ramdisk size: 4,496,693 bytes.
- SHA-256 of extracted kernel in both images: fc38df3ee16f80b37294a60d57fd60284399f728e9702e874944a89dce240031.
- The included prebuilt/kernel has the same SHA-256 as the extracted stock kernel.
- Both ramdisks are gzip-compressed cpio archives.
- Recovery ramdisk's stock fstab identifies the by-name path prefix:
  /dev/block/platform/mtk-msdc.0/11230000.msdc0/by-name/
- Stock recovery fstab reports userdata ext4 with forceencrypt referencing the metadata partition.
- Stock recovery ramdisk includes init.recovery.mt6735.rc and ueventd.mt6735.rc; the latter defines /dev/touch permissions.

DEVICE FACTS REPORTED BY USER / DEVICE PROPERTIES
- Product/model: Pro11; manufacturer: XSD.
- Board/product family: aeon6735_36_d_n / AEON6735_36_D_N.
- Platform: MT6735; Android 7.0, SDK 24; kernel 3.18.35; ARMv7 32-bit.
- User-confirmed physical display resolution and use orientation: 800x1200 portrait.
- User reports GPT readback lists boot and recovery as 16 MB. Verify exact byte/sector sizes from GPT before building/flashing.

IMPORTANT OPEN ITEMS
1. Confirm exact GPT start sector and sector count for boot/recovery, and the partition byte size.
2. Confirm TWRP source branch/build system compatible with this legacy Android 7-era tree.
3. Verify framebuffer pixel format, rotation, brightness and actual touch input device/event mapping.
4. Determine whether the stock recovery's fstab paths exist in TWRP at runtime.
5. Correctly implement Android 7 force-encryption/metadata decryption. This draft intentionally does NOT mount /data until encryption handling is understood.
6. Validate SELinux policy, init scripts, USB gadget/MTP/ADB and recovery properties.
7. Confirm ext4 support and any required filesystem tools in the selected TWRP build.

SAFETY
- Keep original boot.img, recovery.img, GPT and all raw dumps untouched in at least two safe copies.
- Never expose or share nvram, nvdata, proinfo, protect, seccfg, tee or calibration/security dumps.
- Do not add protect1, protect2, nvdata, nvram, proinfo, seccfg, tee1 or tee2 as user-formatable TWRP partitions.
- Do not format userdata to troubleshoot decryption. Formatting destroys user data and may not solve metadata configuration.
- Do not flash until image size is <= the exact recovery partition size, image header is validated, and a tested restore path exists.

NEXT STEPS
1. Use this scaffold only as a starting point in a compatible TWRP source tree.
2. Review BoardConfig.mk and recovery.fstab for the selected branch.
3. Add verified input/display/USB/init support.
4. Build, inspect output image header and exact size.
5. Prefer a supported temporary boot test if the bootloader/device supports it. Do not assume fastboot boot is supported.

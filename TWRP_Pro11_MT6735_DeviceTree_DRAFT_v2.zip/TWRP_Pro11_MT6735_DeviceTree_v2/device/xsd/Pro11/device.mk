# Minimal product properties based on the stock recovery ramdisk.
PRODUCT_PROPERTY_OVERRIDES += \
    ro.product.device=Pro11 \
    ro.product.model=Pro11 \
    ro.product.brand=XSD \
    ro.sf.lcd_density=210
